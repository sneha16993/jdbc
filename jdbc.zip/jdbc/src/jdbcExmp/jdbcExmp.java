package jdbcExmp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class jdbcExmp {
	void addStudent() throws Exception
	{
		try{
			Class.forName("org.h2.Driver");
		
		Connection con= DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");

		PreparedStatement stmt1=con.prepareStatement("insert into Stud values(201,'Rahul','mvm')");
		
		stmt1.executeUpdate();
		
		stmt1.close();
		con.close();
		System.out.println("Data is Added....");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
}

	public static void main(String[] args) throws Exception 
	{
		jdbcExmp now=new jdbcExmp();
		now.addStudent();
	}

}
